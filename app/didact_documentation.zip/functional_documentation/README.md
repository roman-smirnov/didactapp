# Android Client Javadocs
## Usage
1. Right click on index.html
2. Open with <your favourite browser>
3. enjoy